package medicure;

import hib.dto.Appointment;
import javax.swing.JOptionPane;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Medicure {
    public static void main(String[] args) {
       
        Configuration c1 = new Configuration();
        Configuration c2 = c1.configure();
        SessionFactory sf = c2.buildSessionFactory();
        Session session = sf.openSession();
        Transaction tx = session.beginTransaction();
//      String patientId = JOptionPane.showInputDialog("Enter patientId");


        Appointment apt = new Appointment("A10", "Raja", 98, 65, "male", "20/01/2023", "Indore", "5:00pm", "High Fever");
        session.save(apt);
        tx.commit();
        session.close();
        System.out.println("Record Inserted!!!");
        }
    }
