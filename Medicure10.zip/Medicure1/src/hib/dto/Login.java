package hib.dto;

public class Login {
 
    private String id;
    private String password;
    private String post;

    public Login() {
    }

    public Login(String id, String password, String post) {
        this.id = id;
        this.password = password;
        this.post = post;
    }

    
    
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPost() {
        return post;
    }

    public void setPost(String post) {
        this.post = post;
    }
    
}
