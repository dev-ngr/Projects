package hib.dto;

public class DoctorInformation {

    private String doctorId;
    private String doctorName;
    private long contact;
    private String gender;
    private String degree;
    private int experience;
    private String specialisation;
    private String availableTime;

    public DoctorInformation() {
    }

    public DoctorInformation(String doctorId, String doctorName, long contact, String gender, String degree, int experience, String specialisation, String availableTime) {
        this.doctorId = doctorId;
        this.doctorName = doctorName;
        this.contact = contact;
        this.gender = gender;
        this.degree = degree;
        this.experience = experience;
        this.specialisation = specialisation;
        this.availableTime = availableTime;
    }

    
    
    public String getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(String doctorId) {
        this.doctorId = doctorId;
    }

    public String getDoctorName() {
        return doctorName;
    }

    public void setDoctorName(String doctorName) {
        this.doctorName = doctorName;
    }

    public long getContact() {
        return contact;
    }

    public void setContact(long contact) {
        this.contact = contact;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getDegree() {
        return degree;
    }

    public void setDegree(String degree) {
        this.degree = degree;
    }

    public int getExperience() {
        return experience;
    }

    public void setExperience(int experience) {
        this.experience = experience;
    }

    public String getSpecialisation() {
        return specialisation;
    }

    public void setSpecialisation(String specialisation) {
        this.specialisation = specialisation;
    }

    public String getAvailableTime() {
        return availableTime;
    }

    public void setAvailableTime(String availableTime) {
        this.availableTime = availableTime;
    }
    
}
