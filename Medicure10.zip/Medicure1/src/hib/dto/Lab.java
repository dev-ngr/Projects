package hib.dto;

public class Lab {

    private String labNo;
    private String name;
    private String floor;
    private String drName;
    private String time;

    public Lab() {
    }

    public Lab(String labNo, String name, String floor, String drName, String time) {
        this.labNo = labNo;
        this.name = name;
        this.floor = floor;
        this.drName = drName;
        this.time = time;
    }

    
    
    
    public String getLabNo() {
        return labNo;
    }

    public void setLabNo(String labNo) {
        this.labNo = labNo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFloor() {
        return floor;
    }

    public void setFloor(String floor) {
        this.floor = floor;
    }

    public String getDrName() {
        return drName;
    }

    public void setDrName(String drName) {
        this.drName = drName;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
    
    
}
