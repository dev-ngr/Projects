package hib.dto;

public class Appointment {
    
    private String patientId;
    private String name;
    private long contact;
    private int age;
    private String gender;
    private String appointmentDate;
    private String address;
    private String appointmentTime;
    private String problemDescription;

    public Appointment() {
    }

    public Appointment(String patientId, String name, long contact, int age, String gender, String appointmentDate, String address, String appointmentTime, String problemDescription) {
        this.patientId = patientId;
        this.name = name;
        this.contact = contact;
        this.age = age;
        this.gender = gender;
        this.appointmentDate = appointmentDate;
        this.address = address;
        this.appointmentTime = appointmentTime;
        this.problemDescription = problemDescription;
    }
    
    
    public String getPatientId() {
        return patientId;
    }

    public void setPatientId(String patientId) {
        this.patientId = patientId;
        
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getContact() {
        return contact;
    }

    public void setContact(long contact) {
        this.contact = contact;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getAppointmentDate() {
        return appointmentDate;
    }

    public void setAppointmentDate(String appointmentDate) {
        this.appointmentDate = appointmentDate;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAppointmentTime() {
        return appointmentTime;
    }

    public void setAppointmentTime(String appointmentTime) {
        this.appointmentTime = appointmentTime;
    }

    public String getProblemDescription() {
        return problemDescription;
    }

    public void setProblemDescription(String problemDescription) {
        this.problemDescription = problemDescription;
    } 
    }
    

