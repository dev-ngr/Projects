package hib.dto;
public class PatientInformation {

    private String patientId;
    private String name;
    private long contact;
    private String age;
    private String gender;
    private boolean admit;
    private String wardNo;
    private String address;
    private String description;
    private String DrName;

    public PatientInformation() {
    }

    public PatientInformation(String patientId, String name, long contact, String age, String gender, boolean admit, String wardNo, String address, String description, String DrName) {
        this.patientId = patientId;
        this.name = name;
        this.contact = contact;
        this.age = age;
        this.gender = gender;
        this.admit = admit;
        this.wardNo = wardNo;
        this.address = address;
        this.description = description;
        this.DrName = DrName;
    }

    
    
    
    
    public String getPatientId() {
        return patientId;
    }

    public void setPatientId(String patientId) {
        this.patientId = patientId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getContact() {
        return contact;
    }

    public void setContact(long contact) {
        this.contact = contact;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public boolean isAdmit() {
        return admit;
    }

    public void setAdmit(boolean admit) {
        this.admit = admit;
    }

    public String getWardNo() {
        return wardNo;
    }

    public void setWardNo(String wardNo) {
        this.wardNo = wardNo;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDrName() {
        return DrName;
    }

    public void setDrName(String DrName) {
        this.DrName = DrName;
    }

       
}
