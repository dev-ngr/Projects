package hib.dto;

public class Blood {

    private String bloodtype;
    private String available;

    public String getAvailable() {
        return available;
    }

    
    public Blood() {
    }

    public Blood(String bloodtype, String available) {
        this.bloodtype = bloodtype;
        this.available = available;
    }

  
    
    public String getBloodtype() {
        return bloodtype;
    }

    public void setBloodtype(String bloodtype) {
        this.bloodtype = bloodtype;
    }

    public String Available() {
        return available;
    }

    public void setAvailable(String available) {
        this.available = available;
    }

    
}
