package hib.dto;
public class Query {

    private String contact;
    private String description;

    public Query() {
    }

    public Query(String contact, String description) {
        this.contact = contact;
        this.description = description;
    }

    
    
    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    
}
