package practice;

import hib.dto.Appointment;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class ShowAllRecords {
    public static void main(String...args){

        SessionFactory sf = new Configuration().configure().buildSessionFactory();
        Session session = sf.openSession();
        
//        Query q = session.createQuery("from Appointment");.
        
        Criteria q = session.createCriteria(Appointment.class);
//                    select * from tablename

        List<Appointment> app1 = q.list();
        if(app1 == null){
            System.out.println("no record found");
        }
        else{
            for(Appointment app : app1){
                System.out.println(app.getName() + " " + app.getAppointmentTime() + " " + app.getAppointmentDate());
            }
        }
        session.close();
    }
}
