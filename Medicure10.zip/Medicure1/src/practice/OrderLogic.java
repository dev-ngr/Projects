package practice;

import hib.dto.Appointment;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Order;

public class OrderLogic {
    public static void main(String...args){
        SessionFactory sf = new Configuration().configure().buildSessionFactory();
        Session session = sf.openSession();
        
//        Query q = session.createQuery("from Appointment order by patientId in asc");.
        
        Criteria q = session.createCriteria(Appointment.class);
        
//        q.addOrder(Order.asc("patientId"));
//        q.addOrder(Order.desc("name"));
        
        q.addOrder(Order.asc("age"));
        List<Appointment> app1 = q.list();
        if(app1 == null){
            System.out.println("no record found");
        }
        else{
            for(Appointment app : app1){
                System.out.println(app.getName() + " " + app.getAppointmentTime() + " " + app.getAppointmentDate());
            }
        }
        session.close();
    }
}
