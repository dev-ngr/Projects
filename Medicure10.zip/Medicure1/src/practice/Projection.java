package practice;

import hib.dto.Appointment;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.Criteria;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;

public class Projection {
        public static void main(String...args){
            SessionFactory sf = new Configuration().configure().buildSessionFactory();
            Session session = sf.openSession();
            
//            Criteria q = session.createCriteria(Appointment.class);
//            q.setFirstResult(2);
//            q.setMaxResults(2);    
//            List <Appointment> app1 = q.list();
            
              Criteria q = session.createCriteria(Appointment.class);
              ProjectionList pl = Projections.projectionList();
//              pl.add(Projections.property("name"));
//              pl.add(Projections.property("city"));
              pl.add(Projections.max("appointmentDate"));
              pl.add(Projections.min("appointmentDate"));
              pl.add(Projections.count("name"));
              pl.add(Projections.countDistinct("name"));
              q.setProjection(pl);
              
            List<Object[]> app1 = q.list();
            if(app1 == null){
                System.out.println("No record found");
            }
            else{
                for(Object app[] : app1){
                    System.out.println(app[0] + " " + app[1] + " " + app[2] + " " + app[3]);
                }
            }
            session.close();
        }
}
