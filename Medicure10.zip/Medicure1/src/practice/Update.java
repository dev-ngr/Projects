package practice;

import hib.dto.Appointment;
import java.util.Scanner;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Update {
public static void main(String...args){
    
    SessionFactory sf = new Configuration().configure().buildSessionFactory();
    Session session = sf.openSession();
    Transaction tx = session.beginTransaction();
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter PatientId to update the record");
    String patientId = sc.next();
    
//    Company cmp = (Company)session.get(Company, rNo);
    Appointment app = (Appointment)session.get(Appointment.class, patientId);
    if(app==null){
        System.out.println("No record found to update");
    }
    else{
        System.out.println("--MENU--");
        System.out.println("What do you want to Update");
        System.out.println("1. patientId");
        System.out.println("2. Name");
        System.out.println("3. Contact");
        System.out.println("4. Age");
        System.out.println("5. Gender");
        System.out.println("6. Appointment Date");
        System.out.println("7. Address");
        System.out.println("8. AppointmentTime");
        System.out.println("9. problemDescription");
        
        int choice = sc.nextInt();
        switch(choice){
            case 1:
                System.out.println("Enter the updated patientId");
                String upatientId = sc.next();
                app.setPatientId(upatientId);
                session.update(app);
                tx.commit();
                System.out.println("Field Updated!!");
                break;
                
            case 2:
                System.out.println("Enter the updated Name");
                String uname = sc.next();
                app.setName(uname);
                session.update(app);
                tx.commit();
                System.out.println("Field Updated!!");
                break;
                
                case 3:
                System.out.println("Enter the updated contact");
                Long uContact = sc.nextLong();
                app.setContact(uContact);
                session.update(app);
                tx.commit();
                System.out.println("Field Updated!!");
                break;
                
                case 4:
                System.out.println("Enter the updated age");
                int uage = sc.nextInt();
                app.setAge(uage);
                session.update(app);
                tx.commit();
                System.out.println("Field Updated!!");
                break;
                
                case 5:
                System.out.println("Enter the updated Gender");
                String uGender = sc.next();
                app.setGender(uGender);
                session.update(app);
                tx.commit();
                System.out.println("Field Updated!!");
                break;
                
                case 6:
                System.out.println("Enter the updated AppointmentDate");
                String uappointmentDate = sc.next();
                app.setAppointmentDate(uappointmentDate);
                session.update(app);
                tx.commit();
                System.out.println("Field Updated!!");
                break;
                
                case 7:
                System.out.println("Enter the updated address");
                String uaddress = sc.next();
                app.setAddress(uaddress);
                session.update(app);
                tx.commit();
                System.out.println("Field Updated!!");
                break;
                
                case 8:
                System.out.println("Enter the updated appointmentTime");
                String uappointmentTime = sc.next();
                app.setAppointmentTime(uappointmentTime);
                session.update(app);
                tx.commit();
                System.out.println("Field Updated!!");
                break;
                
                case 9:
                System.out.println("Enter the updated problemDescription");
                String uproblemDescription = sc.next();
                app.setProblemDescription(uproblemDescription);
                session.update(app);
                tx.commit();
                System.out.println("Field Updated!!");
                break;
        }
    }
session.close();    
    }
}

