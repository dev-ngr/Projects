package practice;


import hib.dto.Appointment;
import java.util.Scanner;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Delete {
public static void main(String...args){
    
        Configuration c1 = new Configuration();
        Configuration c2 = c1.configure();
        SessionFactory sf = c2.buildSessionFactory();
        Session session = sf.openSession();
        Transaction tx = session.beginTransaction();

    Scanner sc = new Scanner(System.in);
    System.out.println("Enter PatientId to delete the record");
    String patientId = sc.next();
    
//    Company cmp = (Company)session.get(Company.class, rNo);
      Appointment app = (Appointment)session.get(Appointment.class, patientId);
    if(app==null){
        System.out.println("No record found to delete");
    }
    else{
        session.delete(app);
        tx.commit();
        System.out.println("Record Deleted");
    }
    session.close();    
    }
}
