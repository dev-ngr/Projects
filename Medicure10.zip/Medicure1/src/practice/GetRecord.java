package practice;

import hib.dto.Appointment;
import java.util.Scanner;
import org.hibernate.ObjectNotFoundException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class GetRecord {
public static void main(String...args){
    
        Configuration c1 = new Configuration();
        Configuration c2 = c1.configure();
        SessionFactory sf = c2.buildSessionFactory();
        Session session = sf.openSession();

    Scanner sc = new Scanner(System.in);
    System.out.println("Enter PatientId to load the record");
    String patientId = sc.next();
    
//     Company cmp = (Company)session.get(Company.class, rNo);
//    //select * from tablename where colname=?
//    if(cmp==null){
//        System.out.println("No record found");
//    }
//    else{
//        System.out.println(cmp.getCmpName() + " " + cmp.getCity());
//    }
    
    try
    {
        Appointment app = (Appointment)session.load(Appointment.class, patientId);
    System.out.println(app.getName()+ " " + app.getAddress());
    }catch(ObjectNotFoundException ex){
        System.out.println("No record Found");
    }
    
    }
}
