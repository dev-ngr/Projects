package practice;

import hib.dto.Appointment;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

public class Restriction {
        public static void main(String...args){
            SessionFactory sf = new Configuration().configure().buildSessionFactory();
            Session session = sf.openSession();
            
            Criteria q = session.createCriteria(Appointment.class);
//            q.add(Restrictions.eq("gender", "male
              q.add(Restrictions.and(Restrictions.eq("name", "Raja"), Restrictions.eq("address", "Indore")));
            
//              q.add(Restrictions.gt("patientId", 5));
//              q.add(Restrictions.like("name", "a%"));
//              q.add(Restrictions.like("name", "%a"));
//              q.add(Restrictions.like("name", "%a%"));
              
            List <Appointment> app1 = q.list();
            if(app1 == null){
                System.out.println("No record found");
            }
            else{
                for(Appointment app : app1){
                    System.out.println(app.getPatientId() + " " + app.getName() + " " + app.getAddress());
                }
            }
            session.close();
        }
}
